To program
1. Edit file flashFirmware.bat
2. Change port
SET PORT=COM14 to SET PORT=<your_port>
3. Check ESP32 load the firmware
4. Check sim response IMEI
5. Check SIM get IP